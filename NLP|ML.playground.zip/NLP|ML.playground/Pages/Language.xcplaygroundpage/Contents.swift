/*

Abstract:
    Language Identification.
*/
import NaturalLanguage

let recognizer = NLLanguageRecognizer()

recognizer.processString("habit")

let language = recognizer.dominantLanguage

let hypotheses = recognizer.languageHypotheses(withMaximum: 3)
     
