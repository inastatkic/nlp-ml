import NaturalLanguage
import Foundation

let text = "Hang out with friends"

let options: NLTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]

var activityTagScheme = NLTagScheme("activity")
var activityTag = NLTag("ACTV")

let modelURL = Bundle.main.url(forResource: "ActivityTagger", withExtension: "mlmodelc")!
let activityTaggerModel = try! NLModel(contentsOf: modelURL)

let activityTagger = NLTagger(tagSchemes: [.nameType, activityTagScheme])
activityTagger.setModels([activityTaggerModel], forTagScheme: activityTagScheme)

activityTagger.string = text

activityTagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: activityTagScheme, options: options) { (tag, tokenRange) -> Bool in
    if tag == activityTag {
        let name = text[tokenRange]
        print(name, "Activity", separator: "|")
    }
    return true
}






