import NaturalLanguage
import Foundation

let modelURL = Bundle.main.url(forResource: "ActivityClassifier", withExtension: "mlmodelc")!
let activityTaggerModel = try! NLModel(contentsOf: modelURL)

let prediction = activityTaggerModel.predictedLabel(for: "Run")
