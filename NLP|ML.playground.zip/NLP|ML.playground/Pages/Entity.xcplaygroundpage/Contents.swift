/*

Abstract:
   Identifying People, Places, and Organizations.
*/
import NaturalLanguage

let text = "The Guardian article alleged that the data gathering Dr. Kogan had done was back in 2013."

let tagger = NLTagger(tagSchemes: [.nameType])

tagger.string = text

let range = Range(uncheckedBounds: (text.startIndex, text.endIndex))
let options: NLTagger.Options = [.joinNames, .omitPunctuation, .omitWhitespace]

tagger.setLanguage(.english, range: range)

// Identifying People, Places, and Organizations
let tags: [NLTag] = [.personalName, .placeName, .organizationName]

tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameType, options: options) { (tag, tokenRange) -> Bool in
    if let tag = tag, tags.contains(tag) {
        let name = text[tokenRange]
        print(name, tag.rawValue, separator: "|")
    }
    return true
}
