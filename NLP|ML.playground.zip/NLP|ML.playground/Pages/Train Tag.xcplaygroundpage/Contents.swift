/*

Abstract:
    Train a tagging model to classify natural language text at the word level.
*/
import CreateML
import Foundation

// Load the training data
let data = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/ina/Developer/activity.json"))

// Create a text classifier model
let model = try MLWordTagger(trainingData: data, tokenColumn: "tokens", labelColumn: "labels")

// Write out the training model
try model.write(to: URL(fileURLWithPath: "/Users/ina/Developer/ActivityTagger.mlmodel"))

