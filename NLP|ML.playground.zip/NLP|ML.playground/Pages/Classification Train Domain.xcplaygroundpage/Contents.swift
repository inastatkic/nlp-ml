/*

Abstract:
    Text classifier to train a machine learning model to classify natural language text.
 
    Types:
        - Health
        - Job, Career
        - Finance
        - Family
        - Sex, Communication, Emotions, Partner
        - Friends, Social
        - Spirit, Personal development and growth
        - Fun, Satisfaction
*/
import CreateML
import Foundation

// Load the training data
let trainingData = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/ina/Developer/types.json"))

// Create a text classifier model
let model = try MLTextClassifier(trainingData: trainingData, textColumn: "activity", labelColumn: "type")

// Write out the training model
try model.write(to: URL(fileURLWithPath: "/Users/ina/Developer/ActivityClassifier.mlmodel"))


