/*

Abstract:
    Transfer Learning for Word Tagging.

*/
import CreateML

let modelParameters = MLWordTagger.ModelParameters(algorithm: .transferLearning(.dynamicEmbedding, revision: 1))


