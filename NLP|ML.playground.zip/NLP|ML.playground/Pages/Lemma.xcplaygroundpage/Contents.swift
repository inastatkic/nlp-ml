/*

Abstract:
    Root form of word.
*/
import NaturalLanguage

let text = "Mastering a new song"

let tagger = NLTagger(tagSchemes: [.lemma])

tagger.string = text

let options: NLTagger.Options = [.omitWhitespace]

tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lemma, options: options) { tag, tokenRange in
    if let lemma = tag?.rawValue {
        let word = text[tokenRange]
        print(word, lemma, separator: "->")
    }
    return true
}
