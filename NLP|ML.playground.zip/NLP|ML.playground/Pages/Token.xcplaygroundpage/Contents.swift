/*

Abstract:
    Tokenizing Natural Language Text.
*/
import NaturalLanguage

let text = "Having a fun lunch with hilarious coworker"

// Tokenize text into individual words
let tokenizer = NLTokenizer(unit: .word)
tokenizer.string = text

tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
    print(text[tokenRange])
    return true
}
