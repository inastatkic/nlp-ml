/*
 
 Abstract:
    Classify nouns, verbs and other parts of speech in a string.
 */

import NaturalLanguage

let text = "Mastering a new song"

// Parts of Speech
let tagger = NLTagger(tagSchemes: [.lexicalClass])

tagger.string = text

let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation, .joinNames]
let tags: [NLTag] = [.noun, .verb]

tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: options) { tag, tokenRange in
//    if let tag = tag, tags.contains(tag) {
    if let tag = tag {
        let word = text[tokenRange]
        print(word, tag.rawValue, separator: "|")
    }
    return true
}



