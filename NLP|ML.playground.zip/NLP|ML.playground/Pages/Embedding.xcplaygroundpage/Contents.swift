/*

Abstract:
    Find similar strings based on the proximity of their vectors.
 
    Similar to vectors of words that appear in similar contexts.
 
    Types:
        - Words
        - Sentences
 
        = Activity titles
*/
import NaturalLanguage

let embedding = NLEmbedding.wordEmbedding(for: .english)

// Get vector for word
let vector = embedding?.vector(for: "run")

// Compute distance between two words
let distance = embedding?.distance(between: "run", and: "walk")

// Get nearest neighbors for word
embedding?.enumerateNeighbors(for: "run", maximumCount: 3) { (string, distance) -> Bool in
    print(string, distance)
    return true
}



let text = "Mastering a new song."

if let sentenceEmbedding = NLEmbedding.sentenceEmbedding(for: .english) {
    
    if let vector = sentenceEmbedding.vector(for: text) {
//        print(vector)
    }
    let distance = sentenceEmbedding.distance(between: text, and: "Meet with friends.")
    print(distance)
}



