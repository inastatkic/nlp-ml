/*

Abstract:
   Augment an NLTagger to tag a specific set of terms(single words or short phrases) with a label.
*/
import CreateML

let activities = [
    "Planet": ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
    "Health": ["Run", "Walk", "Sex"]
]

//let parameters = MLGazetteer.ModelParameters(language: .english)
//let planetGazetteer = try! MLGazetteer(dictionary: planets, parameters: parameters) // at development time

// save model...

import NaturalLanguage


let text = "Taking your kid to the Mars"

//let gazetteer = try! NLGazetteer(contentsOf: URL())
let gazetteer = try NLGazetteer(dictionary: activities, language: .english) // at runtime

let tagger = NLTagger(tagSchemes: [.nameTypeOrLexicalClass])

tagger.setGazetteers([gazetteer], for: .nameTypeOrLexicalClass)

tagger.string = text

let range: Range = text.startIndex..<text.endIndex
let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation, .joinNames]

tagger.enumerateTags(in: range, unit: .word, scheme: .nameTypeOrLexicalClass, options: options) { tag, tokenRange in
    if let tag = tag {
        let word = text[tokenRange]
        print(word, tag.rawValue, separator: "|")
    }
    return true
}

