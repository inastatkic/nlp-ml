/*

Abstract:
    
*/
import CreateML
import Foundation

// Load the training data
let data = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/ina/Developer/sentiment.json"))
//data.columnNames

// Split data
let (training, testing) = data.randomSplit(by: 0.8, seed: 5)

// Create a text classifier model
let model = try MLTextClassifier(trainingData: training, textColumn: "text", labelColumn: "label")

// Training accuracy as a percentage
let trainingAccuracy = (1.0 - model.trainingMetrics.classificationError) * 100

// Validation accuracy as a percentage
let validationAccuracy = (1.0 - model.validationMetrics.classificationError) * 100

// Evaluate the Classifier’s Accuracy
//let evaluationMetrics = model.evaluation(on: testing)
// Evaluation accuracy as a percentage
//let evaluationAccuracy = (1.0 - evaluationMetrics.classificationError) * 100


let metadata = MLModelMetadata(author: "Ina", shortDescription: "A model trained to classify activity sentiment")

// Write out the training model
try model.write(to: URL(fileURLWithPath: "/Users/ina/Developer/ActivitySentiment.mlmodel"), metadata: metadata)
