/*

Abstract:
   Categorized by sentiment.
*/
import NaturalLanguage

let text = "It's a good life."

let tagger = NLTagger(tagSchemes: [.sentimentScore])

tagger.string = text

let (sentiment, _) = tagger.tag(at: text.startIndex, unit: .sentence, scheme: .sentimentScore)
sentiment?.rawValue
